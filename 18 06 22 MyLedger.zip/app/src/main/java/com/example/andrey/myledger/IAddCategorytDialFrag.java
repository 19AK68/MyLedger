package com.example.andrey.myledger;

import android.app.DialogFragment;

interface IAddCategorytDialFrag {

    public void onDialogPositiveClick(DialogFragment dialog);
    public void onDialogNegativeClick(DialogFragment dialog);
}

package com.example.andrey.myledger;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Context;
import android.support.v4.app.FragmentTransaction;

public interface  ClickListener {




        void onItemClicked(Long accountID);


}

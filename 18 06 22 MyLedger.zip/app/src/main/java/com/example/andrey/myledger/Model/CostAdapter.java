package com.example.andrey.myledger.Model;

public class CostAdapter {
}
